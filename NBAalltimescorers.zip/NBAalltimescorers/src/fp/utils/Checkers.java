package fp.utils;

public class Checkers {

	public static void check(String textRestriction, Boolean condition) {
		if (!condition) {
			throw new IllegalArgumentException(
					Thread.currentThread().getStackTrace()[2].getClassName() +
					"." + 
					Thread.currentThread().getStackTrace()[2].getMethodName() +
					": " + 
					textRestriction);
		}
	}

	public static void checkNoNull(Object... parameters) {
		for (int i = 0; i < parameters.length; i++) {
			if (parameters[i] == null) {
				throw new IllegalArgumentException(
						Thread.currentThread().getStackTrace()[2].getClassName() +
						"." + 
						Thread.currentThread().getStackTrace()[2].getMethodName() +
						": the parameter " + (i + 1) + " is null");
			}
		}
	}
}
