package fp;

import java.time.Duration;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

public record points(Boolean topscorer, String scorers,Integer mostpoints, Integer leastpoints, List<String> top3scorers) {

}

